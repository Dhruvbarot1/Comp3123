var http = require("http");
const employees = require('./Employee'); // Import the employees from employee.js

console.log("Lab 03 - NodeJs");

// Define Server Port
const port = process.env.PORT || 5000;

// Create Web Server using CORE API
const server = http.createServer((req, res) => {
    res.setHeader('Content-Type', 'application/json'); // Set response to JSON by default

    if (req.method !== 'GET') {
        res.statusCode = 405;
        res.end(JSON.stringify({ error: http.STATUS_CODES[405] }));
    } else {
        if (req.url === '/') {
            // Display welcome message as HTML
            res.setHeader('Content-Type', 'text/html');
            res.end("<h1>Welcome to Lab Exercise 03</h1>");
        } else if (req.url === '/employee') {
            // Display all details for employees in JSON format
            res.end(JSON.stringify(employees));
        } else if (req.url === '/employee/names') {
            // Display only employee names (first name + last name) in Ascending order
            const employeeNames = employees
                .map(emp => `${emp.firstName} ${emp.lastName}`)
                .sort();
            res.end(JSON.stringify(employeeNames));
        } else if (req.url === '/employee/totalsalary') {
            // Calculate and display the total salary of all employees
            const totalSalary = employees.reduce((sum, emp) => sum + emp.Salary, 0);
            res.end(JSON.stringify({ total_salary: totalSalary }));
        } else {
            // Handle 404 Not Found
            res.statusCode = 404;
            res.end(JSON.stringify({ error: http.STATUS_CODES[404] }));
        }
    }
});

// Start the server
server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});
